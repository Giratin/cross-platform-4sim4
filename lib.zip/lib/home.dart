import 'package:flutter/material.dart';

import 'CustomWigets/productinfo.dart';

class Home extends StatefulWidget {
  const Home({Key? key}) : super(key: key);

  @override
  State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> {
  List<GameData> _games = [];

  final String _description = "On the other hand, we denounce with righteous "
      "indignation and dislike men who are so beguiled and demoralized by the charms of pleasure of "
      "the moment, so blinded by desire, that they cannot foresee the pain and trouble that are bound to ensue;"
      " and equal blame belongs to those who fail in their duty through weakness of will";

  @override
  void initState() {
    _games.add(GameData(
        "assets/images/dmc5.jpg", "Devil My Cry", _description, 20, 200));
    _games.add(
        GameData("assets/images/fifa.jpg", "FIFA 22", _description, 20, 200));
    _games.add(GameData("assets/images/rdr2.jpg", "Red Dead Redemption II",
        _description, 20, 200));
    _games.add(GameData(
        "assets/images/minecraft.jpg", "Minecraft", _description, 20, 200));
    _games.add(GameData(
        "assets/images/nfs.jpg", "Need For Speed Heat", _description, 20, 200));
    _games.add(GameData(
        "assets/images/re8.jpg", "Resident Evil VIII", _description, 20, 200));
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: const Text("G-Store ESPRIT"),
        ),
        body: ListView.builder(
            itemCount: _games.length,
            itemBuilder: (BuildContext context, int index) {
              return ProductInfo(
                  _games[index].image,
                  _games[index].title,
                  _games[index].description,
                  _games[index].quantity,
                  _games[index].price);
            }));
  }
}

class GameData {
  final String image;
  final String title;
  final String description;
  final int quantity;
  final int price;

  GameData(this.image, this.title, this.description, this.quantity, this.price);

  @override
  String toString() {
    return "GameData: { image: $image, title: $title,description: $description, quantity: $quantity, price: $price }";
  }
}
