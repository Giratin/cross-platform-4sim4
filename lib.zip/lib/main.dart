import 'package:flutter/material.dart';
import 'package:my_app/CustomWigets/product_details.dart';
import 'package:my_app/CustomWigets/signup.dart';
import 'package:my_app/home.dart';

import 'CustomWigets/productinfo.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      debugShowCheckedModeBanner: false,
      home: const MyHomePage(),
    );
  }
}

class MyHomePage extends StatelessWidget {
  const MyHomePage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    const String _description = "On the other hand, we denounce with righteous "
        "indignation and dislike men who are so beguiled and demoralized by the charms of pleasure of "
        "the moment, so blinded by desire, that they cannot foresee the pain and trouble that are bound to ensue;"
        " and equal blame belongs to those who fail in their duty through weakness of will";

    return const SignUp();
    // return const ProductDetails(
    //     "assets/images/dmc5.jpg", "Devil May Cry 5", _description, 200, 3000);
    // return const Home();

    // return Scaffold(
    //   appBar: AppBar(
    //     leading: const Icon(Icons.arrow_back_ios),
    //     title: const Text("G-Store ESPRIT"),
    //     actions: const [
    //       IconButton(onPressed: null, icon: Icon(Icons.ac_unit)),
    //       IconButton(onPressed: null, icon: Icon(Icons.power_settings_new)),
    //     ],
    //   ),
    //   body: ListView(
    //     children: const [
    //       ProductInfo(
    //           "assets/images/dmc5.jpg", "Devil My Cry", _description, 10, 200),
    //       ProductInfo(
    //           "assets/images/fifa.jpg", "FIFA 22", _description, 10, 100),
    //       ProductInfo("assets/images/minecraft.jpg", "Minecraft", _description,
    //           10, 150),
    //       ProductInfo("assets/images/nfs.jpg", "Need For Speed Heat",
    //           _description, 10, 100),
    //       ProductInfo("assets/images/re8.jpg", "Resident Evil VIII",
    //           _description, 10, 200),
    //       ProductInfo("assets/images/re8.jpg", "Resident Evil VIII",
    //           _description, 10, 200),
    //       ProductInfo("assets/images/re8.jpg", "Resident Evil VIII",
    //           _description, 10, 200),
    //       ProductInfo("assets/images/re8.jpg", "Resident Evil VIII",
    //           _description, 10, 200),
    //     ],
    //   ),
    // );
  }
}
