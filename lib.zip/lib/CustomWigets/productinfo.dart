import 'package:flutter/material.dart';

class ProductInfo extends StatelessWidget {
  final String _image;
  final String _title;
  final String _description;
  final int _quantity;
  final int _price;

  const ProductInfo(
      this._image, this._title, this._description, this._quantity, this._price);

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 120,
      child: Card(
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              margin: const EdgeInsets.fromLTRB(10, 10, 20, 10),
              child: Image.asset(
                _image,
                width: 150,
                height: 94,
              ),
            ),
            Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(_title),
                Text(
                  _price.toString() + " TND",
                  textScaleFactor: 2,
                )
              ],
            )
          ],
        ),
      ),
    );
  }
}
